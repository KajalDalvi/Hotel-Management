﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotel_management
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hOTEL_MGTDataSet5.Room' table. You can move, or remove it, as needed.
            this.roomTableAdapter.Fill(this.hOTEL_MGTDataSet5.Room);

        }


        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int noOfDays = int.Parse(textBox3.Text);
                string roomType = comboBox1.SelectedItem.ToString();
                int charges = CalculateCharges(roomType, noOfDays);

                double gstPer = 20;
                double totalcharge = charges + (charges * gstPer / 100);

                textBox5.Text = charges.ToString();
                textBox6.Text = totalcharge.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter valid input values" + ex.Message);

            }
            textBox5.Visible = true;
            textBox6.Visible = true;
        }

        private int CalculateCharges(string roomType, int noOfDays)
        {
            int charges = 0;
            switch (roomType)
            {
                case "Single":
                    charges = noOfDays > 5 ? 800 * noOfDays : 1100 * noOfDays;
                    if (noOfDays > 5)
                    {

                    }
                    break;
                case "Double":
                    charges = noOfDays > 5 ? 1800 * noOfDays : 2000 * noOfDays;
                    break;
                case "Suite":

                    if (noOfDays > 5)
                    {
                        charges = 2100 * noOfDays;
                    }
                    else
                    {
                        charges = 2500 * noOfDays;
                    }
                    break;
                case "Deluxe":
                    charges = 3000 * noOfDays;
                    break;
            }
            return charges;
        }



        private void button1_Click(object sender, EventArgs e)
        {


            dataGridView1.DataSource = null;

            
            if (int.TryParse(textBox1.Text, out int customerId))
            {
                SearchReservation(customerId);
            }
            else
            {
                MessageBox.Show("Please enter a valid Customer ID.");
            }
        }

        private void SearchReservation(int customerId)
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(cs))
            {
                string query = "SELECT R_Type, R_No, Wifi, entryin, entryout " +
                               "FROM Room " +
                               "WHERE Cust_id = @Cust_id";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Cust_id", textBox1.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();

                    try
                    {
                        conn.Open();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count > 0)
                        {
                            // Assuming you want to display data in a DataGridView
                            dataGridView1.DataSource = dataTable;

                            // Or populate a form (Form7) with the data from the first row
                            DataRow row = dataTable.Rows[0];
                            string rType = row["R_Type"].ToString();
                            string rNo = row["R_No"].ToString();
                            string wifi = row["Wifi"].ToString();
                            DateTime entryIn = Convert.ToDateTime(row["entryin"]);
                            DateTime entryOut = Convert.ToDateTime(row["entryout"]);
                            string custId = row["Cust_id"].ToString();

                            Form7 form7 = new Form7(rType, rNo, wifi, entryIn, entryOut, custId);
                            form7.Show();
                        }
                        else
                        {
                            MessageBox.Show("No data found for the selected criteria.");
                        }
                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
   }

