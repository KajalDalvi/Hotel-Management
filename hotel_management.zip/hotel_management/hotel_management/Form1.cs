﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace hotel_management
{
    public partial class Form1 : Form
    {
      

        public static string text1;
        public static string text2;
        string reg = "^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$";
        public Form1()
        {
            InitializeComponent();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Fill the all boxes ");
                return;

            }

            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            string query = "select * from login where uname=@username and pass=@password";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@username", textBox1.Text);
                cmd.Parameters.AddWithValue("@password", textBox2.Text);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows == true)
                    {
                        MessageBox.Show("Login Successfull");
                        Form2 form2 = new Form2();
                        form2.Show();
                    }
                    else
                    {
                        MessageBox.Show("No data found for the selected criteria.");
                    }
                    conn.Close();
                    textBox1.Clear();
                    textBox2.Clear();
                }
            }
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           Form5 form = new Form5();
            form.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            text1 = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            text2= textBox2.Text;   
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox2.Text, reg) == true)
            {
                textBox2.Focus();
                errorProvider2.SetError(this.textBox2, "Please enter correct password");
            }
            else
            {
                errorProvider2.Clear();
            }
        }
        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}  
