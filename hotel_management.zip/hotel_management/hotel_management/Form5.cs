﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace hotel_management
{
    public partial class Form5 : Form
    {
        public static string username;
        public static string password;
        public static string conpassword;
        string reg = "^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$";
        public Form5()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Fill the all boxes");
                return;

            }
            if (textBox2.Text == textBox3.Text)
            {
                conpassword = textBox3.Text;
                password = textBox2.Text;
                MessageBox.Show("Registeration is complete");
                Form1 from = new Form1();
                from.Activate(); 
                from.Show();
            }
            else
            {
                MessageBox.Show("password is wrong");
            }

            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string query = "insert into login Values(@username,@password)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@username",textBox1.Text);
            cmd.Parameters.AddWithValue("@password",textBox2.Text);
            //cmd.Parameters.AddWithValue("@conpassword",textBox3.Text);
            int a = cmd.ExecuteNonQuery();
            conn.Close();        
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            username= textBox1.Text;    
        }
        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form = new Form1();
            username = textBox1.Text;
            password = textBox2.Text;
            conpassword = textBox3.Text;
            form.Show();
        }
        private void textBox1_Leave(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(textBox1.Text)==true)
            {
                textBox1.Focus();
                errorProvider1.SetError(this.textBox1, "Please enter username");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if(Regex.IsMatch(textBox2.Text,reg)==true)
            {
                textBox2.Focus();
                errorProvider2.SetError(this.textBox2, "Invalid Password");
            }
            else
            {
                errorProvider2.Clear();
            }

        }
        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox3.Text,reg)==true)
            {
                textBox3.Focus();
                errorProvider3.SetError(this.textBox3, "Please enter conpassword");
            }
            else
            {
                errorProvider3.Clear();
            }
        }
        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
