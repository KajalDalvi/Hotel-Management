﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;

namespace hotel_management
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public void RefreshView()
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            {
                string query = "select * from Client";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            string query = "insert into Client Values(@Cust_id,@fname,@lname,@address,@Phone_no)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Cust_id",textBox1.Text);
            cmd.Parameters.AddWithValue("@fname", textBox2.Text);
            cmd.Parameters.AddWithValue("@lname", textBox3.Text);
            cmd.Parameters.AddWithValue("@Phone_no", textBox4.Text);
            cmd.Parameters.AddWithValue("@address", textBox5.Text);
            conn.Open();
            int a = cmd.ExecuteNonQuery();
            if(a>0)
            {
                MessageBox.Show("Client Added Succefully");
            }
            else
            {
                MessageBox.Show("Sorry");
            }
            conn.Close();
            RefreshView();
            dataGridView1.Visible = true;

            Form4 form = new Form4();   
            form.Show();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();   
            form.Show();
            this.Close();
        }
        
        private void button4_Click(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            string query = "update Client set fname=@firstname,lname=@lastname,Phone_no=@phone,address=@add where Cust_id=@custid";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@custid", textBox1.Text);
            cmd.Parameters.AddWithValue("@firstname", textBox2.Text);
            cmd.Parameters.AddWithValue("@lastname", textBox3.Text);
            cmd.Parameters.AddWithValue("@phone", textBox4.Text);
            cmd.Parameters.AddWithValue("@add", textBox5.Text);
            conn.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Client updated Successfully");
            }
            else
            {
                MessageBox.Show("Sorry");
            }
            conn.Close();
            RefreshView();
            dataGridView1.Visible = true;

            Form4 form = new Form4();
            form.Show();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hOTEL_MGTDataSet4.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter2.Fill(this.hOTEL_MGTDataSet4.Client);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            string query = "DELETE FROM Client  WHERE Cust_id= @id";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", textBox1.Text);
            
            conn.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Client deleted Successfully");
            }
            else
            {
                MessageBox.Show("Sorry");
            }
            conn.Close();
            RefreshView();
            dataGridView1.Visible = true;

            Form4 form = new Form4();
            form.Show();
            textBox1.Clear();
           
        }
        private void button5_Click_1(object sender, EventArgs e)
        {
            Form4 form = new Form4();   
            form.Show();
        }
    }
}
