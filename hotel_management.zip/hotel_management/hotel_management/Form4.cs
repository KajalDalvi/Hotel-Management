﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
namespace hotel_management
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        public void RefreshView()
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            {
                string query = "select * from Room";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();

            string checkQuery = "SELECT COUNT(*) FROM Room WHERE R_No = @R_No AND ((@entryin BETWEEN entryin AND entryout) OR (@entryout BETWEEN entryin AND entryout) OR (entryin BETWEEN @entryin AND @entryout) OR (entryout BETWEEN @entryin AND @entryout))";
            SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
            checkCmd.Parameters.AddWithValue("@R_No", comboBox2.Text);
            checkCmd.Parameters.AddWithValue("@entryin", dateTimePicker1.Value);
            checkCmd.Parameters.AddWithValue("@entryout", dateTimePicker2.Value);

            int count = (int)checkCmd.ExecuteScalar();
            if (count > 0)
            {
                MessageBox.Show("Room is already booked for the selected date.");
            }
            else
            {

                string query = "INSERT INTO Room (R_Type, R_No, Wifi, entryin, entryout, Cust_id) VALUES (@R_Type, @R_No, @Wifi, @entryin, @entryout, @Cust_id)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@R_Type", comboBox1.Text);
                cmd.Parameters.AddWithValue("@R_No", comboBox2.Text);
                cmd.Parameters.AddWithValue("@Wifi", comboBox3.Text);
                cmd.Parameters.AddWithValue("@entryin", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@entryout", dateTimePicker2.Value);
                cmd.Parameters.AddWithValue("@Cust_id", textBox1.Text);

                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    MessageBox.Show("Room is booked");
                }
                else
                {
                    MessageBox.Show("Sorry, booking failed");
                }
                conn.Close();

                RefreshView();
                dataGridView1.Visible = true;
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                comboBox3.SelectedIndex = -1;
                textBox1.Clear();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(cs))
            {
                string query = "SELECT * FROM Room WHERE  Cust_id = @Cust_id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Cust_id", textBox1.Text);
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string rType = reader["R_Type"].ToString();
                            string rNo = reader["R_No"].ToString();
                            string wifi = reader["Wifi"].ToString();
                            DateTime entryIn = Convert.ToDateTime(reader["entryin"]);
                            DateTime entryOut = Convert.ToDateTime(reader["entryout"]);
                            string custId = reader["Cust_id"].ToString();

                            Form7 form7 = new Form7(rType, rNo, wifi, entryIn, entryOut, custId);
                            form7.Show();
                        }
                        else
                        {
                            MessageBox.Show("No data found for the selected criteria.");
                        }
                    }
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(cs);
            string query = "delete from Room where Cust_id=@Customer";
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            sqlCommand.Parameters.AddWithValue("@Customer", textBox1.Text);

            sqlConnection.Open();
            int a = sqlCommand.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Record Deleted Successfully....!!!");
            }
            else
            {
                MessageBox.Show("Record Not Deleted...!!!");
            }
            sqlConnection.Close();
        } 
    }
    }

