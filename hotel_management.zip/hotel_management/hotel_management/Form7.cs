﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace hotel_management
{
    public partial class Form7 : Form
    {
        
        public Form7(string rType, string rNo, string wifi, DateTime entryIn, DateTime entryOut, string custId)
        {
            InitializeComponent();
            textBox1.Text = custId;
            textBox2.Text = rNo;
            textBox3.Text = rType;
            textBox4.Text = wifi;
            textBox5.Text = entryIn.ToString("yyyy-MM-dd");
            textBox6.Text = entryOut.ToString("yyyy-MM-dd");

        }
        private void button1_Click(object sender, EventArgs e)
        {
            //string customerId = textBox1.Text;
            //string roomNo = textBox2.Text;
            //string roomType = textBox3.Text;
            //string wifi = textBox4.Text;
            //string inDate = textBox5.Text;
            //string outDate = textBox6.Text;


            //string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            //SqlConnection conn = new SqlConnection(cs);
            //try
            //{
            //    conn.Open();
            //    string query = "INSERT INTO Reserve1 (Cust_id, R_No, R_Type, Wifi, entryin, entryout) VALUES (@Cus, @r_No, @r_Type, wifi, @entryi, @entryo)";

            //    SqlCommand cmd = new SqlCommand(query, conn);
            //    cmd.Parameters.AddWithValue("@Cus", customerId);
            //    cmd.Parameters.AddWithValue("@r_No", roomNo);
            //    cmd.Parameters.AddWithValue("@r_Type", roomType);
            //    cmd.Parameters.AddWithValue("@wifi", wifi);
            //    cmd.Parameters.AddWithValue("@entryi", inDate);
            //    cmd.Parameters.AddWithValue("@entryo", outDate);

            //    cmd.ExecuteNonQuery();
            //    MessageBox.Show("Reservation  Saved Successfull");
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

            //conn.Close();
            //textBox1.Clear();
            //textBox2.Clear();
            //textBox3.Clear();
            //textBox4.Clear();
            //textBox5.Clear();
            //textBox6.Clear();

            //RefreshView();
            //dataGridView1.Visible = true;
            MessageBox.Show("Record Added");

        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void RefreshView()
        {
            string cs = ConfigurationManager.ConnectionStrings["HotelDB"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            {
                string query = "select * from Reserve";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
               

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 from = new Form4();
            from.Show();
            this.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Show();
            this.Close();
        }
        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
